
Demonstration of how to create the NMI handler
