# GBDK example for the Mega Duck Laptop
How to interface with the special hardware on the Mega Duck Laptop models ("Super QuiQue" and "Super Junior Computer").

## Keyboard example
- Initializing the external controller connected over the serial link port
- Polling the keyboard for input and processing the returned keycodes
- Displays the typed keys on the screen along with a cursor movable using the arrow keys

