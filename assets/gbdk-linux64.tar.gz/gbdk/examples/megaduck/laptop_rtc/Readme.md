# GBDK example for the Mega Duck Laptop
How to interface with the special hardware on the Mega Duck Laptop models ("Super QuiQue" and "Super Junior Computer").

## RTC example
- Initializing the external controller connected over the serial link port
- Polling the laptop RTC for date and time
- Setting a new date and time for the laptop RTC

