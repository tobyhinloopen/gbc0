
Large Map
=========

Shows how to scroll with maps larger than 32 x 32 tiles using set_bkg_submap(). 

It fills rows and columns at the edges of the visible viewport (of the hardware 
Background Map) with the desired sub-region of the large map as it scrolls.


Overworld Map and Tiles are by ArMM1998:
https://opengameart.org/content/gameboy-tileset
License(s): CC0

