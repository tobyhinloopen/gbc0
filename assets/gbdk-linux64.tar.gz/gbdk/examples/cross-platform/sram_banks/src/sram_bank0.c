#include <gbdk/platform.h>
#include <stdint.h>
#include <stdio.h>

#pragma dataseg DATA_0  // Sets Cart SRAM bank to 0

int sram_bank_var_0;  /* In Cart SRAM bank 0 */
