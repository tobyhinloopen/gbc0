#include <gbdk/platform.h>
#include <stdint.h>
#include <stdio.h>

#pragma dataseg DATA_1  // Sets Cart SRAM bank to 1

int sram_bank_var_1;  /* In Cart SRAM bank 1 */
