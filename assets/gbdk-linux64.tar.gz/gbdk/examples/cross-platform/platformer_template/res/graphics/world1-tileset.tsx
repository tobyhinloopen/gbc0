<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="world1" tilewidth="8" tileheight="8" tilecount="160" columns="8">
 <image source="world1-tileset.png" trans="ff00ff" width="64" height="32"/>
</tileset>
