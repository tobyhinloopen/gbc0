
extern const char * sgb_sfx_names_table_a[];
extern const char * sgb_sfx_names_table_b[];
