# GBDK example for the Game Boy MBC3 Real Time Clock (RTC)
How to interface with the MBC3 Real Time Clock

## RTC example
- Polling the RTC and displaying elapsed time
- Resetting the RTC to zero

See the Pandocs MBC3 documentation for additional hardware details:
https://gbdev.io/pandocs/MBC3.html