#pragma once

#include <gbdk/platform.h>

extern SFR my_hram_variable;