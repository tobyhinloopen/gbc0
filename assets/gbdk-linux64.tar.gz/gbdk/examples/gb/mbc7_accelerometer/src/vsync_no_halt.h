
#ifndef _VSYNC_NO_HALT_H
#define _VSYNC_NO_HALT_H

void vsync_no_halt(void);

#endif
