Updated version of the original Sound Sample that merges 
in changes made at: https://github.com/gbdk-2020/GBSoundDemo

Keys:
- Select: change current channel menu
- Start: play current Sound
- Start + A: play a song
- Arrows: navigate throught options
- Arrows + A: Increments/Decrements current value by 10
- Arrows + B: Increments/Decrements current value by 100
- Arrows + A + B: set Min/Max value to current option
- Select + A: Dump Registers

